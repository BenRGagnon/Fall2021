#!/bin/bash

echo "Welcome to computer science society."
echo $(date)

echo "Number of Directories: "
numOfDirectories= ls -d ~/*/ | wc -l

echo "Path= "$PATH
echo "User= "$USER
echo "SHELL= "$SHELL
df

echo "Please, could you loan me \$25.00?"
echo "if x=2, x*x=4, x/2 = 1"

ls c*.sh

echo "Goodbye at: " ; date +"%H hours"
